package org.tech.talk;

import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoCollection;
import org.bson.Document;
import org.bson.conversions.Bson;

import javax.inject.Inject;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

@Path("/hello")
public class GreetingResource {

    @Inject
    MongoClient mongoClient;

    @GET
    @Produces(MediaType.TEXT_PLAIN)
    public String hello() {

        Bson query = new Document()
                .append("name", "Mercury")
                .append("hasRings", false);

        MongoCollection<Document> collection = mongoClient.getDatabase("sample_guides").getCollection("planets");

        Document infoCliente = collection.find(query).first();

        return infoCliente!= null ? infoCliente.toString() : "No data";
    }
}